package com.sun.jersey.samples.jaxb;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class JAXBXmlRootElement {

    public String value;

    public JAXBXmlRootElement() {
    }

    public JAXBXmlRootElement(String str) {
        value = str;
    }
}
